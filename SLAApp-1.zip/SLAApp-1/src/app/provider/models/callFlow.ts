export class CallFlow {
   id:string;
   callFlowName:string;
   disabled:boolean;
}