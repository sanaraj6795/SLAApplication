import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { CookieService } from 'ngx-cookie-service';
import { User } from '../models/user';
import * as jwt_decode from 'jwt-decode';
export const TOKEN_NAME: string = 'jwt_token';

@Injectable({ providedIn: 'root' })
export class AuthenticationService {
    private currentUserSubject: any;
    //public currentUser: Observable<User>;
    private serviceUrl = '';
    userCredentials:User;

    constructor(private http: HttpClient,private cookieService:CookieService) {
        this.currentUserSubject = JSON.parse(localStorage.getItem('currentUser'));
       // this.currentUser = this.currentUserSubject.asObservable();
        
    }

    public get currentUserValue() {
        return this.currentUserSubject;
    }

    getTokenExpirationDate(token: string): Date {
        const decoded = jwt_decode(token);
        console.log(decoded)
        if (decoded === undefined)
          return null;
        const date = new Date(0);
        date.setUTCSeconds(Number(decoded));
        return date;
      }
    
      isTokenExpired(token?: string): boolean {
       // if (!token) token = this.getToken();
        if (!token) return true;
        const date = this.getTokenExpirationDate(token);
        if (date === undefined || date === null) return false;
        return !(date.valueOf() > new Date().valueOf());
      }
    
    getUserDetails(){
      var retrievedObject = localStorage.getItem('CurrentUser');
        return JSON.parse(retrievedObject);
    }

    getUserManagementDetails(): Observable<any> {
      const headers = new HttpHeaders({'X-XSRF-TOKEN': `${this.cookieService.get('XSRF-TOKEN')}`});
      return this.http.get<any>("https://localhost:44362/api/UserManagement")
      .pipe(map(user => {
        return user
      }));
  }

    login(username, password) {
      const headers = new HttpHeaders({'Content-Type':'application/json'});
      console.log("I am called in service")
      let encodedUsername= btoa(username);
      let encodedPassword= btoa(password);
      
      this.userCredentials={UserName:encodedUsername,Password:encodedPassword};
        return this.http.post<any>("https://localhost:44362/api/Login", this.userCredentials, {headers: headers})
            .pipe(map(user => {
               let token="";
               token=jwt_decode(user.token);
               console.log(token);
               var testobj={};
                // store user details and jwt token in local storage to keep user logged in between page refreshes
                localStorage.setItem('CurrentUser',JSON.stringify(token));
                localStorage.setItem('Token',user.token);
                return user;
            }));
    }

    logout() {
        // remove user from local storage and set current user to null
        localStorage.removeItem('currentUser');
        this.currentUserSubject.next(null);
    }
}