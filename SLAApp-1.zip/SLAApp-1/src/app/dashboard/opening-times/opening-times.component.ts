import { Component, OnInit } from '@angular/core';
import {DashboardService} from '../../provider/services/dashboard.service';

@Component({
  selector: 'app-opening-times',
  templateUrl: './opening-times.component.html',
  styleUrls: ['./opening-times.component.css']
})
export class OpeningTimesComponent implements OnInit {
  days:string[]=['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'];

  constructor() { }
   checkHolidayDays:boolean;
   mondayStart:any;
  ngOnInit() {
    this.mondayStart="11:30";
    this.checkHolidayDays=false;
    console.log(localStorage.getItem('CallFlowName'));
  }

}
