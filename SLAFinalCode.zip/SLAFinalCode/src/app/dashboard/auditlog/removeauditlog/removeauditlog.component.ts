import { Component, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Component({
  selector: 'app-removeauditlog',
  templateUrl: 'removeauditlog.component.html'
})
export class RemoveAuditLogComponent {

  constructor(
    public dialogRef: MatDialogRef<RemoveAuditLogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) { }

  onNoClick(): void {
    this.dialogRef.close(false);
  }

  onOkClick(){
    this.dialogRef.close(true);
  }
}


