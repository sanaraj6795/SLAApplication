import { Component, OnInit } from '@angular/core';
import { DashboardService } from '../../provider/services/dashboard.service';
import { ToasterService } from 'angular2-toaster';

@Component({
  selector: 'app-auditlog',
  templateUrl: './auditlog.component.html',
  styleUrls: ['./auditlog.component.css']
})
export class AuditLogComponent implements OnInit {
  auditLogValue:any;
 
  constructor(private dashboardService: DashboardService,
    private toasterService: ToasterService) {
  }
  ngOnInit() {
    this.dashboardService.getAuditLog().subscribe(
      data => {
        this.auditLogValue=data;
      },
      error => {
      });
  }

  OnClearClick(){
     this.dashboardService.OnAuditClear().subscribe(
      data => {
        this.ngOnInit();
        this.toasterService.pop("success", "Audit Log", "Log has been cleared successfully");
      },
      error => {
        this.toasterService.pop("error", "Audit Log", "Server error has occured!!!");
      });
  }
}
