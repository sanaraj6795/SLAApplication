import { Component, OnInit } from '@angular/core';
import { DashboardService } from 'src/app/provider/services/dashboard.service';
import { DivertModel, TeamRedirectModel } from 'src/app/provider/models/DivertModel';
import {  IdTextModel } from 'src/app/provider/models/IdTextModel';
import { ToasterService } from 'angular2-toaster';
import { FormBuilder,FormArray,FormGroup } from '@angular/forms';
@Component({
  selector: 'app-divert',
  templateUrl: './divert.component.html',
  styleUrls: ['./divert.component.css']
})
export class DivertComponent implements OnInit {
  
  DivertModel: DivertModel;
  callFlowId: string;
  mainArray = [];
  redirectcount: number;
  constructor(private dashboardService: DashboardService, private toasterService: ToasterService,private formBuilder: FormBuilder) { }

  ngOnInit() {
  
    this.getDivert();

    // this.holidayservice.GetHolidayDetails().subscribe(
     //  data => this.Holiday = data );
       
  }
  Remove(a) {
    this.mainArray.splice(a, 1);
  }

  getDivert() {
    this.dashboardService.getDivertDetails().subscribe((data: any) => {
      
      this.DivertModel = data;
      this.consructdata(this.DivertModel);
      this.redirectcount = this.DivertModel.teamRedirect.redirectCounter;
      error => {

      }

    });
  }

  consructdata(data: DivertModel) {
    let result = [];
    
    for (let i = 0; i < data.teamRedirectDate.length; i++) {

      result[i] = {
        date: this.formatDate(data.teamRedirectDate[i].text),
        textopen: data.teamRedirectOpen[i].text,
        textclose: data.teamRedirectClose[i].text,
        closed: data.teamRedirectClosed[i].text == "on" ? true : false,
        routing: data.teamRedirectRouting[i].text =="true"?true : false,
        message:data.teamRedirectMessage[i].text =="true"?true : false,
        number:data.teamRedirectNumber[i].text,
      }

    }
    
    this.mainArray = result;
  }

  AddDate() {
    if (this.mainArray.length < this.redirectcount) {
      this.mainArray.push(
        {
          date: "",
          textopen: "",
          textclose: "",
          closed: false,
          routing:false,
          message:false,
          number:"", 

        }

      );
    }
    else {
      alert("Maximum no. data's for this CallFlow is " + this.redirectcount);
    }
  }

  makeRequestData(inputData: any[]) {
    let outputData: DivertModel = new DivertModel();
    let id: string;
    let teamRedirect:TeamRedirectModel;
    let teamRedirectDate: IdTextModel[] = [];
    let teamRedirectOpen: IdTextModel[] = [];
    let teamRedirectClose: IdTextModel[] = [];
    let teamRedirectClosed: IdTextModel[] = [];
    let teamRedirectRouting: IdTextModel[] = [];
    let teamRedirectMessage: IdTextModel[] = [];
    let teamRedirectNumber: IdTextModel[] = [];
    for (let i = 0; i < inputData.length; i++) {
      teamRedirectDate.push({ id: i < 9 ? "0" + (i + 1) : (i + 1).toString(), text: this.reverseformate(inputData[i].date) });

      teamRedirectOpen.push({ id: i < 9 ? "0" + (i + 1) : (i + 1).toString(), text: inputData[i].textopen });

      teamRedirectClose.push({ id: i < 9 ? "0" + (i + 1) : (i + 1).toString(), text: inputData[i].textclose });

      teamRedirectClosed.push({ id: i < 9 ? "0" + (i + 1) : (i + 1).toString(), text: inputData[i].closed == true ? "on" : "off" });

      teamRedirectRouting.push({ id: i < 9 ? "0" + (i + 1) : (i + 1).toString(), text: inputData[i].routing == true ? "true" : "false"});

      teamRedirectMessage.push({ id: i < 9 ? "0" + (i + 1) : (i + 1).toString(), text: inputData[i].message == true ? "true" : "false"});

      teamRedirectNumber.push({ id: i < 9 ? "0" + (i + 1) : (i + 1).toString(), text: inputData[i].number });
    }
    outputData.id=this.DivertModel.id;
    outputData.teamRedirect=this.DivertModel.teamRedirect;
    outputData.teamRedirectDate = teamRedirectDate;
    outputData.teamRedirectClose = teamRedirectClose;
    outputData.teamRedirectOpen = teamRedirectOpen;
    outputData.teamRedirectClosed = teamRedirectClosed;
    outputData.teamRedirectRouting= teamRedirectRouting;
    outputData.teamRedirectMessage= teamRedirectMessage;
    outputData.teamRedirectNumber= teamRedirectNumber;

    return outputData;
  }

  formatDate(date: string) {
    let datearr = date.split('/');
    return datearr[2] + "-" + datearr[1] + "-" + datearr[0];
  }

  reverseformate(date: string) {
    let date1 = date.split('-');
    return date1[2] + "/" + date1[1] + "/" + date1[0];
  }

  updateDate() {
    let newDivertModel = this.makeRequestData(this.mainArray);
    //this.newDivertModel = this.DivertModel; //updated holidays list to be assigned to newteamRedirectDatesDetails
    this.dashboardService.updateDiverting(newDivertModel).subscribe(data => {
      this.toasterService.pop("success", "Divert", "File has been updated successfully");
    },
      error => {
        this.toasterService.pop("error", "Divert", "Server error has occured!!!");
      }
    );

  }
  /*
  DivertForm:FormGroup;
  constructor(private dashboardService: DashboardService, private toasterService: ToasterService,private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.createForm();
    this.getDivert();

  }
   createForm()
   {
     this.DivertForm=this.formBuilder.group({
       id:['',''],
       teamRedirect:this.formBuilder.group(this.CreateteamRedirect()),
       teamRedirectDate:this.formBuilder.array([this.CreateIdTextModel()]),
       teamRedirectOpen:this.formBuilder.array([this.CreateIdTextModel()]),
       teamRedirectClose:this.formBuilder.array([this.CreateIdTextModel()]),
       teamRedirectClosed:this.formBuilder.array([this.CreateIdTextModel()]),
       teamRedirectRouting:this.formBuilder.array([this.CreateIdTextModel()]),
       teamRedirectMessage:this.formBuilder.array([this.CreateIdTextModel()]),
       teamRedirectNumber:this.formBuilder.array([this.CreateIdTextModel()]),
     })
   }
   CreateteamRedirect():FormGroup{
     return this.formBuilder.group({
      checkTeamRedirect:['',''],

      individualMessages:['',''],
 
      redirectCounter:['',''],

     });
   }
   CreateIdTextModel():FormGroup{
     return this.formBuilder.group({
      id: ['',''],
      text: ['',''],
     })
   }



   getDivert() {
    this.dashboardService.getDivertDetails().subscribe((data: any) => {
      
      data => {
        this.DivertForm.setValue({
          id:data.id,
       teamRedirect:data.teamRedirect,
       teamRedirectDate:data.teamRedirectDate,
       teamRedirectOpen:data.teamRedirectOpen,
       teamRedirectClose:data.teamRedirectClose,
       teamRedirectClosed:data.teamRedirectClosed,
       teamRedirectRouting:data.teamRedirectRouting,
       teamRedirectMessage:data.teamRedirectMessage,
       teamRedirectNumber:data.teamRedirectNumber,
      });
    
      }
      console.log(data);
      console.log(this.DivertForm);
      error => {
      }
    });
     
    
   }
   get f() { return this.DivertForm.controls; }

   
*/
}
