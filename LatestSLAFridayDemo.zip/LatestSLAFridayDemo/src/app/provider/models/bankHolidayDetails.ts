import { IdTextModel } from './IdTextModel';

export class BankHolidayDetails {
   bankHoliday: IdTextModel[];
   bankHolidayOpen: IdTextModel[];
   bankHolidayClose: IdTextModel[];
   bankHolidayClosed: IdTextModel[];
}

export class BankHolidayEnabled {
   checkHolidayDays: boolean;
   holidayCounter: number;
   individualMessages: boolean;
   id: string;
}