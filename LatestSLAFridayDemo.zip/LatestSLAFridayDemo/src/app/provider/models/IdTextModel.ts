export class IdTextModel {

    id: string;
    text: string;
 
}