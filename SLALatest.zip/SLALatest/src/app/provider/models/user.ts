export class User {
    //id: number;
    UserName: string;
    Password:string;
    //token: string;
}