import { Component, OnInit } from '@angular/core';
import {DashboardService} from '../../provider/services/dashboard.service';

@Component({
  selector: 'app-opening-times',
  templateUrl: './opening-times.component.html',
  styleUrls: ['./opening-times.component.css']
})
export class OpeningTimesComponent implements OnInit {
  days:string[]=['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'];
  value:any;
  checkHolidayDays:boolean;
  mondayStart:any;
  
  constructor(private dashboardService:DashboardService) { }

  ngOnInit() {
    this.mondayStart="11:30";
    this.checkHolidayDays=false;
    let callFlowId=localStorage.getItem('CallFlowId');
    this.dashboardService.getOpeningTimes(callFlowId).subscribe(
      data => {
       this.value=data;
       console.log(this.value)
      },
      error => {
        console.log(error);
      }); 
  }

}
