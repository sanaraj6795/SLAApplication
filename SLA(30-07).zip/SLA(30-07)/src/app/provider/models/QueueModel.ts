export class QueueModel{
    inQueueMessageDelay:number;
    enablePositionInQueue:boolean;
    voicemailOptionEnabled:boolean;
    voicemailOptionTimeout:number;
    voicemailOptionDN:string;
    messageOrder:boolean;
    messageNumber:number;
    enableDivertTime:boolean;
    enableDivertTimeTimer:number;
    enableDivertTimeNumber:string;
    enableDivertCallers:boolean;
    enableDivertCallersLevel:number;
    enableDivertCallersNumber:string;
    id:string;
}
