import { IdTextModel } from './IdTextModel';

export class DivertModel{
     id:string;

     teamRedirect:TeamRedirectModel;

     teamRedirectDate:IdTextModel[];

     teamRedirectOpen:IdTextModel[];

     teamRedirectClose:IdTextModel[];

     teamRedirectClosed:IdTextModel[];

     teamRedirectRouting:IdTextModel[];

     teamRedirectMessage:IdTextModel[];

     teamRedirectNumber:IdTextModel[];
}
export class TeamRedirectModel
{
     checkTeamRedirect:boolean; 

     individualMessages:boolean; 

     redirectCounter:number; 
}