import { Component, OnInit } from '@angular/core';
import { DashboardService } from '../../provider/services/dashboard.service';
import { FormGroup, FormBuilder } from '@angular/forms';
import { ToasterService } from 'angular2-toaster';
import { MatDialog } from '@angular/material';
import {AddLocationComponent} from './addlocation/addlocation.component';

@Component({
  selector: 'app-generalsettings',
  templateUrl: './generalsettings.component.html',
  styleUrls: ['./generalsettings.component.css']
})
export class GeneralSettingsComponent implements OnInit {
  generalSettingsForm: FormGroup;
  locationNames:Array<string>=['Headquaters','AUP (IS)'];
  callValues=[];
  constructor(private dashboardService: DashboardService,
    private formBuilder: FormBuilder,
    private toasterService: ToasterService,
    public dialog: MatDialog) {
  }
  ngOnInit() {
    this.createForm();
    this.callValues = Array(20).fill(0).map((x,i)=>i+1);
    
    /*this.dashboardService.getOutOfHours().subscribe(
      data => {
        this.courseForm.setValue({
          isOutofhoursmessageEnabled: data.enableMessageOOH,
          isOutofhoursCallEnabled: data.enableVoicemailRedirectOOH,
          enabledoutofhoursMessageNumber: data.dnOOH,
          isHolidayMessageEnabled: data.enableMessageBankHoliday,
          isHolidayCallEnabled: data.enableVoicemailRedirectBankHoliday,
          enabledHolidaysMessageNumber: data.dnBankHoliday,
        });
        this.submittedOutofHoursValue.id = data.id;
      },
      error => {
      });*/
  }

  createForm() {
    this.generalSettingsForm = this.formBuilder.group({
      timecall: ['2', ''],
      locations: [[], ''],
    });
  }

  get f() { return this.generalSettingsForm.controls; }

  onTextChange(existingValue,newValue){
  console.log(existingValue,newValue);
  }
  onCheckChange(event){
console.log(event);
  }

  onSubmit() {
    console.log(this.generalSettingsForm);
    /*this.submittedOutofHoursValue.dnOOH = this.courseForm.get('enabledoutofhoursMessageNumber').value;
    this.submittedOutofHoursValue.enableMessageOOH = this.courseForm.get('isOutofhoursmessageEnabled').value;
    this.submittedOutofHoursValue.enableVoicemailRedirectOOH = this.courseForm.get('isOutofhoursCallEnabled').value;
    this.submittedOutofHoursValue.dnBankHoliday = this.courseForm.get('enabledHolidaysMessageNumber').value;
    this.submittedOutofHoursValue.enableMessageBankHoliday = this.courseForm.get('isHolidayMessageEnabled').value;
    this.submittedOutofHoursValue.enableVoicemailRedirectBankHoliday = this.courseForm.get('isHolidayCallEnabled').value;
    this.dashboardService.updateOutOfHours(this.submittedOutofHoursValue).subscribe(
      data => {
        this.toasterService.pop("success", "Out Of Hours", "File has been updated successfully");
      },
      error => {
        this.toasterService.pop("error", "Out Of Hours", "Server error has occured!!!");
      });*/
  }

  OnRemoveClick(location){
   let indexValue= this.locationNames.indexOf(location);
   this.locationNames.splice(indexValue,1);
  }

  openDialog(): void {
    let dialogRef = this.dialog.open(AddLocationComponent, { 
      panelClass:'custom-dialog-container',
      width: '350px',
      data: {location:''},
      backdropClass: 'dialogBackground'
    });

    dialogRef.afterClosed().subscribe(result => {
      if(result){
      this.locationNames.push(result);
      }
    });
  }
}
