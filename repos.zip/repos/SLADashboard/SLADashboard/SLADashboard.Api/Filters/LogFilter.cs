﻿using Microsoft.AspNetCore.Mvc.Filters;
using SLADashboard.Api.Log;

namespace SLADashboard.Api.Filters
{
    public class LogFilter : ActionFilterAttribute
    {
        private readonly IMessageLogger _messageLogger;

        public LogFilter(IMessageLogger messageLogger)
        {
            _messageLogger = messageLogger;
        }

        public override void OnActionExecuted(ActionExecutedContext context)
        {
            base.OnActionExecuted(context);

            _messageLogger.FlushLogs();
        }
    }
}
