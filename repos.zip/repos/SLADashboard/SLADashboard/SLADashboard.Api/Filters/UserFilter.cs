﻿using Microsoft.AspNetCore.Mvc.Filters;
using SLADashboard.Api.User;

namespace SLADashboard.Api.Filters
{
    public class UserFilter : ActionFilterAttribute, IFilterMetadata
    {
        private readonly IUserService userService;

        public UserFilter(IUserService userService)
        {
            this.userService = userService;
        }

        public override void OnActionExecuting(ActionExecutingContext context)
        {
            var controller = context.RouteData.Values.ContainsKey("controller") ?
                context.RouteData.Values["controller"]?.ToString() : string.Empty;

            var action = context.RouteData.Values.ContainsKey("action") ?
                context.RouteData.Values["action"]?.ToString() : string.Empty;

            if (controller.ToUpper() == "LOGIN" && action.ToUpper() == "LOGIN")
            {
                base.OnActionExecuting(context);                
            }            
            else
            {
                this.userService.CreateUser(context.HttpContext.User);
            }
        }
    }
}
