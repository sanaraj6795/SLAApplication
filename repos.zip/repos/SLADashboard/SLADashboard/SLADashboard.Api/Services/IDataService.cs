﻿using SLADashboard.Api.DTO;

namespace SLADashboard.Api.Services
{
    public interface IDataService
    {
        IPCC CurrentData { get; }

        bool SaveDataAsXml();
    }
}
