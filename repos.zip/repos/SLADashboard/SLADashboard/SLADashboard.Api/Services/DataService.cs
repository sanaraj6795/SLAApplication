﻿using System;
using System.IO;
using System.Xml.Serialization;
using Microsoft.Extensions.Configuration;
using NetCore.AutoRegisterDi;
using SLADashboard.Api.DTO;

namespace SLADashboard.Api.Services
{
    [RegisterAsSingleton]
    public class DataService : IDataService
    {
        private readonly IConfiguration _configuration;

        private readonly string _fileName;

        private readonly object _updateFileLock;

        public DataService(IConfiguration configuration)
        {
            _configuration = configuration;

            if (File.Exists(AppDomain.CurrentDomain.BaseDirectory + @"DashboardXml.xml"))
            {
                _fileName = AppDomain.CurrentDomain.BaseDirectory + @"DashboardXml.xml";
            }
            else
            {
                _fileName = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "bin") + @"\DashboardXml.xml";
            }

            _updateFileLock = new object();

            LoadData();
        }        

        public IPCC CurrentData { get; private set; }

        public bool SaveDataAsXml()
        {
            var fileName = _fileName;
            if(_configuration["Environment"] == "test")
            {
                fileName = _configuration["TestXmlFilePath"];
            }

            var x = new XmlSerializer(typeof(IPCC));
            lock (_updateFileLock)
            {
                using (var writer = new StreamWriter(fileName))
                {
                    x.Serialize(writer, CurrentData);
                }
            }

            return true;
        }

        private void LoadData()
        {
            var x = new XmlSerializer(typeof(IPCC));
            using (var reader = new StreamReader(_fileName))
            {
                CurrentData = x.Deserialize(reader) as IPCC;
            }            
        }
    }
}
