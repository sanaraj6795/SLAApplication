﻿using System.Collections.Generic;
using System.Linq;
using System.Security;
using AutoMapper;
using NetCore.AutoRegisterDi;
using SLADashboard.Api.DTO;
using SLADashboard.Api.Model;
using SLADashboard.Api.Services;
using SLADashboard.Api.User;

namespace SLADashboard.Api.BL
{
    [RegisterAsScoped]
    public class DashboardBL : IDashboardBL
    {
        private readonly IDataService dataService;
        private readonly IUserService userService;
        private readonly IMapper mapper;

        public DashboardBL(IDataService dataService, IUserService userService, IMapper mapper)
        {
            this.dataService = dataService;
            this.userService = userService;
            this.mapper = mapper;
        }

        public IList<UserManagementModel> GetUserManagementDetails()
        {
            var userDetails = this.dataService.CurrentData.UserList;
            var users = userDetails?.User;
            if (users != null)
            {
                return mapper.Map<IList<UserManagementModel>>(users);
            }

            return null;
        }

        public UserSettingsModel GetUserSettings()
        {
            var userId = this.userService.CurrentUser.UserId;
            var userSettingsDetails = this.dataService.CurrentData.UserSettings.Find(b => b.Id == userId);            
            if (userSettingsDetails != null)
            {
                return mapper.Map<UserSettingsModel>(userSettingsDetails);
            }

            return null;
        }

        public IList<TeamsModel> GetTeamsData()
        {
            var teamsData = this.dataService.CurrentData.Teams;
            var teams = teamsData?.Team;
            if (teams != null)
            {
                return mapper.Map<IList<TeamsModel>>(teams);
            }

            return null;
        }

        public BankHolidayDetails GetBankHolidayDetails(string callFlowId)
        {
            var bankHolidayDetails = new BankHolidayDetails();

            var bankHoliday = this.dataService.CurrentData.BankHoliday.Find(b => b.Id == callFlowId)?.BankHolidayDate;
            var bankHolidayOpen = this.dataService.CurrentData.BankHolidayOpen.Find(b => b.Id == callFlowId)?.BankHolidayDate;
            var bankHolidayClose = this.dataService.CurrentData.BankHolidayClose.Find(b => b.Id == callFlowId)?.BankHolidayDate;
            var bankHolidayClosed = this.dataService.CurrentData.BankHolidayClosed.Find(b => b.Id == callFlowId)?.BankHolidayDate;
            
            if (bankHoliday != null)
            {
                bankHolidayDetails.BankHoliday = mapper.Map<List<BankHolidayDate>>(bankHoliday);
            }

            if (bankHolidayOpen != null)
            {
                bankHolidayDetails.BankHolidayOpen = mapper.Map<List<BankHolidayDate>>(bankHolidayOpen);
            }

            if (bankHolidayClose != null)
            {
                bankHolidayDetails.BankHolidayClose = mapper.Map<List<BankHolidayDate>>(bankHolidayClose);
            }

            if (bankHolidayClosed != null)
            {
                bankHolidayDetails.BankHolidayClosed = mapper.Map<List<BankHolidayDate>>(bankHolidayClosed);
            }

            if (bankHolidayDetails != null)
            {
                return bankHolidayDetails;
            }

            return new BankHolidayDetails();
        }

        public BankHolidayEnabledModel GetBankHolidayEnabledData(string callFlowId)
        {
            var bankHolidayEnabled = this.dataService.CurrentData.BankHolidayEnabled.Find(b => b.Id == callFlowId);
            if (bankHolidayEnabled != null)
            {
                return mapper.Map<BankHolidayEnabledModel>(bankHolidayEnabled);
            }

            return new BankHolidayEnabledModel();
        }

        public OpeningTimesModel GetOpeningTimesData(string callFlowId)
        {
            var openingTimes = this.dataService.CurrentData.OpeningTimes.Find(b => b.Id == callFlowId);
            if (openingTimes != null)
            {
                return mapper.Map<OpeningTimesModel>(openingTimes);
            }

            return new OpeningTimesModel();
        }
    }
}
