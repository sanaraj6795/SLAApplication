﻿using System.Collections.Generic;
using SLADashboard.Api.DTO;
using SLADashboard.Api.Model;

namespace SLADashboard.Api.BL
{
    public interface IDashboardBL
    {
        IList<UserManagementModel> GetUserManagementDetails();

        UserSettingsModel GetUserSettings();

        IList<TeamsModel> GetTeamsData();

        BankHolidayDetails GetBankHolidayDetails(string callFlowId);

        BankHolidayEnabledModel GetBankHolidayEnabledData(string callFlowId);

        OpeningTimesModel GetOpeningTimesData(string callFlowId);
    }
}