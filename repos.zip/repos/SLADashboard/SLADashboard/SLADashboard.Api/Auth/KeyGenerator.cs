﻿using System.Text;
using Microsoft.IdentityModel.Tokens;

namespace SLADashboard.Api.Auth
{
    public static class KeyGenerator
    {
        public static SymmetricSecurityKey GetSecurityKey(string key)
        {
            return new SymmetricSecurityKey(Encoding.UTF8.GetBytes(key));
        }
    }
}
