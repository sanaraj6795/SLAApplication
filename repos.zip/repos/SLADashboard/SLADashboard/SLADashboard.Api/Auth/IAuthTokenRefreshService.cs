﻿using SLADashboard.Api.Model;

namespace SLADashboard.Api.Auth
{
    public interface IAuthTokenRefreshService
    {
        string ConfirmUserAndRefreshToken(RefreshTokenRequest refreshTokenRequest);
    }
}