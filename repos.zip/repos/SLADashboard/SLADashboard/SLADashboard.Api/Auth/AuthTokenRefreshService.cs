﻿using NetCore.AutoRegisterDi;
using SLADashboard.Api.Model;
using SLADashboard.Api.User;

namespace SLADashboard.Api.Auth
{
    [RegisterAsScoped]
    public class AuthTokenRefreshService : IAuthTokenRefreshService
    {
        private readonly IUserService _userService;
        private readonly ITokenService _tokenService;

        public AuthTokenRefreshService(IUserService userService, ITokenService tokenService)
        {
            this._userService = userService;
            _tokenService = tokenService;
        }

        public string ConfirmUserAndRefreshToken(RefreshTokenRequest refreshTokenRequest)
        {
            var validRequest = this._userService.CurrentUser.UserId == refreshTokenRequest.UserId
                && this._userService.CurrentUser.UserName == refreshTokenRequest.UserName;
            if (validRequest)
            {
                return _tokenService.GenerateToken(this._userService.CurrentUser);
            }

            return null;
        }
    }
}
