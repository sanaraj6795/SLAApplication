﻿using SLADashboard.Api.Model;
using SLADashboard.Api.User;

namespace SLADashboard.Api.Auth
{
    public interface IAuthService
    {
        AppUser AuthenticateUser(LoginRequest userModel);

        string AuthenticateUserAndGenerateToken(LoginRequest userModel);

        string GenerateAdditionalToken();
    }
}
