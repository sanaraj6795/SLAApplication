﻿using System.Linq;
using NetCore.AutoRegisterDi;
using SLADashboard.Api.Model;
using SLADashboard.Api.Services;
using SLADashboard.Api.User;

namespace SLADashboard.Api.Auth
{
    [RegisterAsSingleton]
    public class AuthService : IAuthService
    {
        private readonly ITokenService _tokenService;
        private readonly IDataService _dataService;

        public AuthService(ITokenService tokenFactory, IDataService dataService)
        {
            this._tokenService = tokenFactory;
            _dataService = dataService;
        }

        public string AuthenticateUserAndGenerateToken(LoginRequest userModel)
        {
            var authenticatedUser = AuthenticateUser(userModel);
            if (authenticatedUser != null)
            {
                return _tokenService.GenerateToken(authenticatedUser);
            }

            return null;
        }

        public string GenerateAdditionalToken()
        {
            return _tokenService.GenerateToken();
        }

        public AppUser AuthenticateUser(LoginRequest userModel)
        {
            if (userModel == null || userModel.IsInvalid()) return null;

            AppUser user = null;

            var userDetail = _dataService.CurrentData.UserList.User.FirstOrDefault(x => x.Text == userModel.ActualUserName);
            if (userDetail != null)
            {
                var userSettings = _dataService.CurrentData.UserSettings.FirstOrDefault(x => x.Id == userDetail.Id);
                if (userSettings != null && userSettings.Password == userModel.Password)
                {
                    user = new AppUser(userModel.ActualUserName, userDetail.Id);
                }
            }

            return user;
        }
    }
}
