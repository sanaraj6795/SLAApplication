﻿using SLADashboard.Api.User;

namespace SLADashboard.Api.Auth
{
    public interface ITokenService
    {
        string GenerateToken(AppUser authenticatedUser);

        string GenerateToken(int size = 64);
    }
}