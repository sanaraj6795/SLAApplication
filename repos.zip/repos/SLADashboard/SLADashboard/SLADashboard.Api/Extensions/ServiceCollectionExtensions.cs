﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;

namespace SLADashboard.Api.Extensions
{
    public static class ServiceCollectionExtensions
    {
        public static void RegisterNonGenericClassesAsSingleton(this IServiceCollection services)
        {
            var assemblies = new List<Assembly>
            {
                Assembly.GetExecutingAssembly()
            };

            var types = assemblies.SelectMany(x => x.GetTypes().Where(t => 
                t.FullName.StartsWith("SLADashboard") && !t.IsInterface && t.IsClass && 
                !t.IsGenericType && t.IsPublic));
            foreach(var type in types)
            {
                var interfaces = type.GetInterfaces().Where(i => i.FullName.StartsWith("SLADashboard")).ToList();
                if (interfaces != null && interfaces.Any())
                {
                    foreach (var parent in interfaces)
                    {
                        services.AddSingleton(parent, type);
                    }
                }
            }
        }
    }
}
