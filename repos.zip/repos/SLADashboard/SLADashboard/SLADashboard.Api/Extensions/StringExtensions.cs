﻿using System;
using System.Text;

namespace SLADashboard.Api.Extensions
{
    public static class StringExtensions
    {
        public static string ConvertFromBase64String(this string input)
        {
            if(string.IsNullOrEmpty(input))
            {
                return input;
            }

            var data = Convert.FromBase64String(input);
            return Encoding.UTF8.GetString(data);
        }

        public static string Base64Encode(this string input)
        {
            if (string.IsNullOrEmpty(input))
            {
                return input;
            }

            var plainTextBytes = System.Text.Encoding.UTF8.GetBytes(input);
            return Convert.ToBase64String(plainTextBytes);
        }
    }
}
