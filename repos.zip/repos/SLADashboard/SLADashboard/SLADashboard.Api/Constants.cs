﻿namespace SLADashboard.Api
{
    public static class Constants
    {
        public const string LogSplitter = "--";
    }

    public static class AuthConstants
    {
        public const string AuthToken = "AuthToken_JWT";
        public const string AntiForgeryToken = "_AntiForgeryToken_";
        public const string AntiForgeryResponseTokenName = "SL:XSRF:RES:TOKEN";
        public const string AntiForgeryRequestTokenName = "SL:XSRF:TOKEN";
    }

    public static class ClaimConstants
    {
        public const string UserName = "==UserName__";
    }
}
