﻿using System;

namespace SLADashboard.Api.Log
{
    public interface IMessageLogger
    {
        void LogMessage(string logMessage, LogLevelEnum logLevel, Guid logId = default, string logStacktrace = "", Exception ex = null, string logMethod = "", string logClass = "", string additionalData = "");

        void FlushLogs();
    }
}
