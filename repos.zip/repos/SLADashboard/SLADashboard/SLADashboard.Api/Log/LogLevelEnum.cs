﻿namespace SLADashboard.Api.Log
{
    public enum LogLevelEnum
    {
        Debug,
        Information,
        Warning,
        Error,
        Fatal
    }
}
