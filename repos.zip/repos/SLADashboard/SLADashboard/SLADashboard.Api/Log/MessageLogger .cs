﻿using System;
using System.Collections.Concurrent;
using System.IO;
using System.Reflection;
using System.Threading.Tasks;
using System.Xml;
using log4net;
using NetCore.AutoRegisterDi;

namespace SLADashboard.Api.Log
{
    [RegisterAsSingleton]
    public class MessageLogger : IMessageLogger
    {
        protected readonly ILog log4netLogger;

        private static readonly string LOG_CONFIG_FILE = @"log4net.config";

        private readonly ConcurrentBag<LogDetail> logs = new ConcurrentBag<LogDetail>();
        private readonly object syncLock = new object();

        public MessageLogger()
        {
            log4net.Util.LogLog.InternalDebugging = true;

            var log4NetConfig = new XmlDocument();
            log4NetConfig.Load(File.OpenRead(LOG_CONFIG_FILE));

            var repo = LogManager.CreateRepository(
                Assembly.GetEntryAssembly(), typeof(log4net.Repository.Hierarchy.Hierarchy));

            log4net.Config.XmlConfigurator.Configure(repo, log4NetConfig["log4net"]);
            this.log4netLogger = log4net.LogManager.GetLogger(
                System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        }

        public void LogMessage(string logMessage, LogLevelEnum logLevel, Guid logId = default, string logStacktrace = "", Exception ex = null, string logMethod = "", string logClass = "", string additionalData = "")
        {
            logs.Add(new LogDetail
            {
                LogMessage = logMessage,
                LogLevel = logLevel,
                StackTrace = logStacktrace,
                Exception = ex,
                MethodName = logMethod,
                ClassName = logClass,
                AdditionalInfo = additionalData,
                LogId = logId
            });
        }

        public void FlushLogs()
        {
            if (logs != null && logs.Count > 0)
            {
                lock (syncLock)
                {
                    Parallel.ForEach(logs, (logItem) =>
                    {
                        var logDetail = logItem.ToString();

                        switch (logItem.LogLevel)
                        {
                            case LogLevelEnum.Debug:
                                log4netLogger.Debug(logDetail);
                                break;
                            case LogLevelEnum.Warning:
                                log4netLogger.Warn(logDetail, logItem.Exception);
                                break;
                            case LogLevelEnum.Error:
                                log4netLogger.Error(logDetail, logItem.Exception);
                                break;
                            case LogLevelEnum.Fatal:
                                log4netLogger.Fatal(logDetail, logItem.Exception);
                                break;
                            default:
                                log4netLogger.Info(logDetail);
                                break;
                        }
                    });

                    logs.Clear();
                }
            }
        }
    }
}
