﻿using System;

namespace SLADashboard.Api.Log
{
    public class LogDetail
    {
        public LogDetail(string message, LogLevelEnum logLevel) : this()
        {
            this.MachineName = Environment.MachineName;
            this.LogDate = DateTime.UtcNow;
            this.LogMessage = message;
            this.LogLevel = logLevel;
        }

        public LogDetail()
        {
            this.MachineName = Environment.MachineName;
            this.LogDate = DateTime.UtcNow;
        }

        public Guid LogId { get; set; }
        public string LogAppId { get; set; }
        public LogLevelEnum LogLevel { get; set; }
        public string LogMessage { get; set; }
        public string StackTrace { get; set; }
        public string MethodName { get; set; }
        public string ClassName { get; set; }
        public string AdditionalInfo { get; set; }
        public DateTime LogDate { get; private set; }
        public string MachineName { get; private set; }
        public string UserId { get; set; }
        public Exception Exception { get; set; }

        public override string ToString()
        {
            var detail = string.Empty;

            if (this.LogId != default)
            {
                detail += $"LogId:{this.LogId}{Constants.LogSplitter}";
            }

            if (!string.IsNullOrEmpty(this.LogAppId))
            {
                detail += $"LogAppId:{this.LogAppId}{Constants.LogSplitter}";
            }

            detail += $"MachineName:{this.MachineName}{Constants.LogSplitter}LogDate:{this.LogDate}{Constants.LogSplitter}LogLevel:{this.LogLevel}{Constants.LogSplitter}LogMessage:{this.LogMessage}{Constants.LogSplitter}";

            if (!string.IsNullOrEmpty(this.MethodName))
            {
                detail += $"MethodName:{this.MethodName}{Constants.LogSplitter}";
            }

            if (!string.IsNullOrEmpty(this.ClassName))
            {
                detail += $"LogId:{this.ClassName}{Constants.LogSplitter}";
            }

            if (!string.IsNullOrEmpty(this.AdditionalInfo))
            {
                detail += $"LogId:{this.AdditionalInfo}{Constants.LogSplitter}";
            }

            if (!string.IsNullOrEmpty(this.UserId))
            {
                detail += $"UserId:{this.UserId}{Constants.LogSplitter}";
            }

            if (!string.IsNullOrEmpty(this.StackTrace))
            {
                detail += $"StackTrace:{this.StackTrace}{Constants.LogSplitter}";
            }

            if (this.Exception != null)
            {
                detail += $"Exception:{this.Exception}{Constants.LogSplitter}";
            }

            return detail;
        }
    }
}
