﻿namespace SLADashboard.Api.Model
{
    public class OpeningTimesModel
    {
        public string DOW_TOD_Check { get; set; }
        
        public string MondayStart { get; set; }
        
        public string MondayEnd { get; set; }
        
        public string MondayClosed { get; set; }
        
        public string MondayOverflow { get; set; }
        
        public string MondayOverflowEnd { get; set; }
        
        public string MondayRoute { get; set; }
        
        public string MondayCSQ { get; set; }
        
        public string TuesdayStart { get; set; }
        
        public string TuesdayEnd { get; set; }
        
        public string TuesdayClosed { get; set; }
        
        public string TuesdayOverflow { get; set; }
        
        public string TuesdayOverflowEnd { get; set; }
        
        public string TuesdayRoute { get; set; }
        
        public string TuesdayCSQ { get; set; }
        
        public string WednesdayStart { get; set; }
        
        public string WednesdayEnd { get; set; }
        
        public string WednesdayClosed { get; set; }
        
        public string WednesdayOverflow { get; set; }
        
        public string WednesdayOverflowEnd { get; set; }
        
        public string WednesdayRoute { get; set; }
        
        public string WednesdayCSQ { get; set; }
        
        public string ThursdayStart { get; set; }
        
        public string ThursdayEnd { get; set; }
        
        public string ThursdayClosed { get; set; }
        
        public string ThursdayOverflow { get; set; }
        
        public string ThursdayOverflowEnd { get; set; }
        
        public string ThursdayRoute { get; set; }
        
        public string ThursdayCSQ { get; set; }
        
        public string FridayStart { get; set; }
        
        public string FridayEnd { get; set; }
        
        public string FridayClosed { get; set; }
        
        public string FridayOverflow { get; set; }
        
        public string FridayOverflowEnd { get; set; }
        
        public string FridayRoute { get; set; }
        
        public string FridayCSQ { get; set; }
        
        public string SaturdayStart { get; set; }
        
        public string SaturdayEnd { get; set; }
        
        public string SaturdayClosed { get; set; }
        
        public string SaturdayOverflow { get; set; }
        
        public string SaturdayOverflowEnd { get; set; }
        
        public string SaturdayCSQ { get; set; }
        
        public string SaturdayRoute { get; set; }
        
        public string SundayStart { get; set; }
        
        public string SundayEnd { get; set; }
        
        public string SundayClosed { get; set; }
        
        public string SundayOverflow { get; set; }
        
        public string SundayOverflowEnd { get; set; }
        
        public string SundayCSQ { get; set; }
        
        public string SundayRoute { get; set; }

        public string Id { get; set; }
    }
}
