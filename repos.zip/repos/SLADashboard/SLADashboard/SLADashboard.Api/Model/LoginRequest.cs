﻿using System.ComponentModel.DataAnnotations;
using SLADashboard.Api.Extensions;

namespace SLADashboard.Api.Model
{
    public class LoginRequest
    {
        [Required]
        public string UserName { get; set; }

        [Required]
        public string Password { get; set; }

        public string ActualUserName { get; private set; }

        public bool IsValid()
        {
            return !string.IsNullOrEmpty(this.UserName) && !string.IsNullOrEmpty(this.Password);
        }

        public bool IsInvalid()
        {
            return string.IsNullOrEmpty(this.UserName) || string.IsNullOrEmpty(this.Password);
        }

        public void Decode()
        {
            this.ActualUserName = this.UserName.ConvertFromBase64String();
            this.Password = this.Password.ConvertFromBase64String();
        }
    }
}
