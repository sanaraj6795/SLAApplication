﻿namespace SLADashboard.Api.Model
{
    public class BankHolidayDate
    {
        public string Id { get; set; }

        public string Text { get; set; }
    }
}
