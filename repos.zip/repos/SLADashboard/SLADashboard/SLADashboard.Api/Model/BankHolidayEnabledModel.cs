﻿using System.Collections.Generic;

namespace SLADashboard.Api.Model
{
    public class BankHolidayEnabledModel
    {
        public string CheckHolidayDays { get; set; }

        public string HolidayCounter { get; set; }

        public string IndividualMessages { get; set; }

        public string Id { get; set; }
    }
}
