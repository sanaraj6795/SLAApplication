﻿namespace SLADashboard.Api.Model
{
    public class TeamsModel
    {
        public string Id { get; set; }

        public string Type { get; set; }
    }
}
