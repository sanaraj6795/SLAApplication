﻿using System.Collections.Generic;

namespace SLADashboard.Api.Model
{
    public class BankHolidayDetails
    {
        public List<BankHolidayDate> BankHoliday { get; set; }

        public List<BankHolidayDate> BankHolidayOpen { get; set; }

        public List<BankHolidayDate> BankHolidayClose { get; set; }

        public List<BankHolidayDate> BankHolidayClosed { get; set; }
    }
}
