﻿using System.Collections.Generic;

namespace SLADashboard.Api.Model
{
    public class UserSettingsModel
    {
        public string Id { get; set; }

        public string AccountType { get; set; }

        public List<CallFlowData> CallFlows { get; set; }        
    }
}
