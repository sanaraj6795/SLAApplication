﻿namespace SLADashboard.Api.Model
{
    public class CallFlowData
    {
        public CallFlowData(string callFlowId, string value)
        {
            CallFlowId = callFlowId;
            Value = bool.TryParse(value, out var temp) && temp;
        }

        public CallFlowData(string callFlowId, bool value)
        {
            CallFlowId = callFlowId;
            Value = value;
        }

        public string CallFlowId { get; private set; }        

        public bool Value { get; private set; }
    }
}
