﻿using System.ComponentModel.DataAnnotations;

namespace SLADashboard.Api.Model
{
    public class RefreshTokenRequest
    {
        [Required]
        public string UserName { get; set; }

        [Required]
        public string UserId { get; set; }
    }
}
