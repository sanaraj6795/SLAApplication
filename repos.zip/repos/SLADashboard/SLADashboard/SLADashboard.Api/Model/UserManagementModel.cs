﻿namespace SLADashboard.Api.Model
{
    public class UserManagementModel
    {
        public string Id { get; set; }

        public string Type { get; set; }
    }
}
