﻿using System.Collections.Generic;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SLADashboard.Api.BL;
using SLADashboard.Api.Model;

namespace SLADashboard.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(Policy = "ApiUser")]
    public class UserManagementController : ControllerBase
    {
        private readonly IDashboardBL dashboardBL;

        public UserManagementController(IDashboardBL dashboardBL)
        {
            this.dashboardBL = dashboardBL;
        }

        [HttpGet]
        public ActionResult<IList<UserManagementModel>> Get()
        {
            var data = dashboardBL.GetUserManagementDetails();

            if (data == null)
            {
                return BadRequest();
            }

            return Ok(data);
        }
    }
}
