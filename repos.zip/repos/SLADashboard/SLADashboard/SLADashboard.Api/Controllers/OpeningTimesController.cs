﻿using System.Collections.Generic;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SLADashboard.Api.BL;
using SLADashboard.Api.DTO;
using SLADashboard.Api.Model;

namespace SLADashboard.Api.Controllers
{
    [ApiController]
    [Authorize(Policy = "ApiUser")]
    public class OpeningTimesController : ControllerBase
    {
        private readonly IDashboardBL dashboardBL;

        public OpeningTimesController(IDashboardBL dashboardBL)
        {
            this.dashboardBL = dashboardBL;
        }

        [Route("api/[controller]")]
        public OpeningTimesModel GetOpeningTimesData(string callFlowId)
        {
            return dashboardBL.GetOpeningTimesData(callFlowId);
        }
    }
}
