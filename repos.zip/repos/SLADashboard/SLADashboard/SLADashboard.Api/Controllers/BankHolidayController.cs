﻿using System.Collections.Generic;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SLADashboard.Api.BL;
using SLADashboard.Api.DTO;
using SLADashboard.Api.Model;

namespace SLADashboard.Api.Controllers
{
    [ApiController]
    [Authorize(Policy = "ApiUser")]
    public class BankHolidayController : ControllerBase
    {
        private readonly IDashboardBL dashboardBL;

        public BankHolidayController(IDashboardBL dashboardBL)
        {
            this.dashboardBL = dashboardBL;
        }

        [Route("api/[controller]/BankHolidayDetails")]
        public BankHolidayDetails GetBankHolidayDetails(string callFlowId)
        {
            return dashboardBL.GetBankHolidayDetails(callFlowId);
        }

        [Route("api/[controller]/BankHolidayEnabled")]
        public BankHolidayEnabledModel GetBankHolidayEnabledData(string callFlowId)
        {
            return dashboardBL.GetBankHolidayEnabledData(callFlowId);
        }
    }
}
