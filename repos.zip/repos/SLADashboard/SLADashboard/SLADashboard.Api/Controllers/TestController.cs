﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using SLADashboard.Api.DTO;
using SLADashboard.Api.Filters;
using SLADashboard.Api.Log;
using SLADashboard.Api.Services;

namespace SLADashboard.Api.Controllers
{
    //[EnableCors()]
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(Policy = "ApiUser")]
    public class TestController : ControllerBase
    {
        private readonly IMessageLogger _messageLogger;
        private readonly IDataService dataService;

        public TestController(IMessageLogger messageLogger, IDataService dataService)
        {
            this._messageLogger = messageLogger;
            this.dataService = dataService;
        }
                
        [HttpGet]
        public ActionResult<Teams> Get()
        {
            //_messageLogger.LogMessage("called Get", LogLevelEnum.Information);
            return this.dataService.CurrentData.Teams;
        }

        [HttpPost]
        public ActionResult<bool> Post()
        {
            return Ok(this.dataService.SaveDataAsXml());
        }
    }
}
