﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SLADashboard.Api.Auth;
using SLADashboard.Api.Model;

namespace SLADashboard.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(Policy = "ApiUser")]
    public class LoginController : ControllerBase
    {
        private readonly IAuthService _authService;
        private readonly IAuthTokenRefreshService _authTokenRefreshService;

        public LoginController(IAuthService authService, IAuthTokenRefreshService authTokenRefreshService)
        {
            _authService = authService;
            _authTokenRefreshService = authTokenRefreshService;
        }

        [AllowAnonymous]
        [IgnoreAntiforgeryToken]
        [HttpPost]
        public IActionResult Login([FromBody] LoginRequest loginRequest)
        {
            loginRequest.Decode();

            var token = _authService.AuthenticateUserAndGenerateToken(loginRequest);

            if (!string.IsNullOrEmpty(token))
            {
                return Ok(new { token });
            }

            return Unauthorized();
        }

        //[IgnoreAntiforgeryToken]
        //[HttpGet]
        //[Route("[action]")]
        //public IActionResult GetToken()
        //{
        //    var tokens = _authService.GenerateToken();

        //    if (tokens != null)
        //    {
        //        HttpContext.Response.Cookies.Append(AuthConstants.AntiForgeryResponseTokenName, tokens, new Microsoft.AspNetCore.Http.CookieOptions
        //        {
        //            HttpOnly = false
        //        });

        //        return NoContent();
        //    }

        //    return BadRequest();
        //}

        [HttpPost]
        [Route("[action]")]
        public IActionResult RefreshToken([FromBody] RefreshTokenRequest refreshTokenRequest)
        {
            var tokenString = _authTokenRefreshService.ConfirmUserAndRefreshToken(refreshTokenRequest);

            if (!string.IsNullOrEmpty(tokenString))
            {
                return Ok(tokenString);
            }

            return BadRequest();
        }
    }
}
