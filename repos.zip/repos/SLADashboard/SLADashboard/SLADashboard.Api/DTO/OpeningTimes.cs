﻿using System.Xml.Serialization;

namespace SLADashboard.Api.DTO
{
    [XmlRoot(ElementName = "OpeningTimes")]
    public class OpeningTimes
    {
        [XmlElement(ElementName = "DOW_TOD_Check")]
        public string DOW_TOD_Check { get; set; }
        [XmlElement(ElementName = "mondayStart")]
        public string MondayStart { get; set; }
        [XmlElement(ElementName = "mondayEnd")]
        public string MondayEnd { get; set; }
        [XmlElement(ElementName = "mondayClosed")]
        public string MondayClosed { get; set; }
        [XmlElement(ElementName = "mondayOverflow")]
        public string MondayOverflow { get; set; }
        [XmlElement(ElementName = "mondayOverflowEnd")]
        public string MondayOverflowEnd { get; set; }
        [XmlElement(ElementName = "mondayRoute")]
        public string MondayRoute { get; set; }
        [XmlElement(ElementName = "mondayCSQ")]
        public string MondayCSQ { get; set; }
        [XmlElement(ElementName = "tuesdayStart")]
        public string TuesdayStart { get; set; }
        [XmlElement(ElementName = "tuesdayEnd")]
        public string TuesdayEnd { get; set; }
        [XmlElement(ElementName = "tuesdayClosed")]
        public string TuesdayClosed { get; set; }
        [XmlElement(ElementName = "tuesdayOverflow")]
        public string TuesdayOverflow { get; set; }
        [XmlElement(ElementName = "tuesdayOverflowEnd")]
        public string TuesdayOverflowEnd { get; set; }
        [XmlElement(ElementName = "tuesdayRoute")]
        public string TuesdayRoute { get; set; }
        [XmlElement(ElementName = "tuesdayCSQ")]
        public string TuesdayCSQ { get; set; }
        [XmlElement(ElementName = "wednesdayStart")]
        public string WednesdayStart { get; set; }
        [XmlElement(ElementName = "wednesdayEnd")]
        public string WednesdayEnd { get; set; }
        [XmlElement(ElementName = "wednesdayClosed")]
        public string WednesdayClosed { get; set; }
        [XmlElement(ElementName = "wednesdayOverflow")]
        public string WednesdayOverflow { get; set; }
        [XmlElement(ElementName = "wednesdayOverflowEnd")]
        public string WednesdayOverflowEnd { get; set; }
        [XmlElement(ElementName = "wednesdayRoute")]
        public string WednesdayRoute { get; set; }
        [XmlElement(ElementName = "wednesdayCSQ")]
        public string WednesdayCSQ { get; set; }
        [XmlElement(ElementName = "thursdayStart")]
        public string ThursdayStart { get; set; }
        [XmlElement(ElementName = "thursdayEnd")]
        public string ThursdayEnd { get; set; }
        [XmlElement(ElementName = "thursdayClosed")]
        public string ThursdayClosed { get; set; }
        [XmlElement(ElementName = "thursdayOverflow")]
        public string ThursdayOverflow { get; set; }
        [XmlElement(ElementName = "thursdayOverflowEnd")]
        public string ThursdayOverflowEnd { get; set; }
        [XmlElement(ElementName = "thursdayRoute")]
        public string ThursdayRoute { get; set; }
        [XmlElement(ElementName = "thursdayCSQ")]
        public string ThursdayCSQ { get; set; }
        [XmlElement(ElementName = "fridayStart")]
        public string FridayStart { get; set; }
        [XmlElement(ElementName = "fridayEnd")]
        public string FridayEnd { get; set; }
        [XmlElement(ElementName = "fridayClosed")]
        public string FridayClosed { get; set; }
        [XmlElement(ElementName = "fridayOverflow")]
        public string FridayOverflow { get; set; }
        [XmlElement(ElementName = "fridayOverflowEnd")]
        public string FridayOverflowEnd { get; set; }
        [XmlElement(ElementName = "fridayRoute")]
        public string FridayRoute { get; set; }
        [XmlElement(ElementName = "fridayCSQ")]
        public string FridayCSQ { get; set; }
        [XmlElement(ElementName = "saturdayStart")]
        public string SaturdayStart { get; set; }
        [XmlElement(ElementName = "saturdayEnd")]
        public string SaturdayEnd { get; set; }
        [XmlElement(ElementName = "saturdayClosed")]
        public string SaturdayClosed { get; set; }
        [XmlElement(ElementName = "saturdayOverflow")]
        public string SaturdayOverflow { get; set; }
        [XmlElement(ElementName = "saturdayOverflowEnd")]
        public string SaturdayOverflowEnd { get; set; }
        [XmlElement(ElementName = "saturdayCSQ")]
        public string SaturdayCSQ { get; set; }
        [XmlElement(ElementName = "saturdayRoute")]
        public string SaturdayRoute { get; set; }
        [XmlElement(ElementName = "sundayStart")]
        public string SundayStart { get; set; }
        [XmlElement(ElementName = "sundayEnd")]
        public string SundayEnd { get; set; }
        [XmlElement(ElementName = "sundayClosed")]
        public string SundayClosed { get; set; }
        [XmlElement(ElementName = "sundayOverflow")]
        public string SundayOverflow { get; set; }
        [XmlElement(ElementName = "sundayOverflowEnd")]
        public string SundayOverflowEnd { get; set; }
        [XmlElement(ElementName = "sundayCSQ")]
        public string SundayCSQ { get; set; }
        [XmlElement(ElementName = "sundayRoute")]
        public string SundayRoute { get; set; }
        [XmlAttribute(AttributeName = "id")]
        public string Id { get; set; }
    }
}
