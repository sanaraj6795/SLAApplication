﻿using System.Collections.Generic;
using System.Xml.Serialization;

namespace SLADashboard.Api.DTO
{
    [XmlRoot(ElementName = "IPCC")]
    public class IPCC
    {
        [XmlElement(ElementName = "Teams")]
        public Teams Teams { get; set; }

        [XmlElement(ElementName = "General")]
        public General General { get; set; }

        [XmlElement(ElementName = "Emergency")]
        public Emergency Emergency { get; set; }

        [XmlElement(ElementName = "UserList")]
        public UserList UserList { get; set; }

        [XmlElement(ElementName = "UserSettings")]
        public List<UserSettings> UserSettings { get; set; }

        [XmlElement(ElementName = "Locations")]
        public Locations Locations { get; set; }

        [XmlElement(ElementName = "BankHolidayEnabled")]
        public List<BankHolidayEnabled> BankHolidayEnabled { get; set; }

        [XmlElement(ElementName = "OpeningTimes")]
        public List<OpeningTimes> OpeningTimes { get; set; }

        [XmlElement(ElementName = "IVR")]
        public List<IVR> IVR { get; set; }

        [XmlElement(ElementName = "WelcomeMessage")]
        public List<WelcomeMessage> WelcomeMessage { get; set; }

        [XmlElement(ElementName = "Motd")]
        public List<Motd> Motd { get; set; }

        [XmlElement(ElementName = "Queue")]
        public List<Queue> Queue { get; set; }

        [XmlElement(ElementName = "OutOfHours")]
        public List<OutOfHours> OutOfHours { get; set; }

        [XmlElement(ElementName = "TeamRedirect")]
        public List<TeamRedirect> TeamRedirect { get; set; }

        [XmlElement(ElementName = "RoutePoints")]
        public RoutePoints RoutePoints { get; set; }

        [XmlElement(ElementName = "CallFlowGeneral")]
        public List<CallFlowGeneral> CallFlowGeneral { get; set; }

        [XmlElement(ElementName = "TeamRedirectDate")]
        public List<TeamRedirectDate> TeamRedirectDate { get; set; }

        [XmlElement(ElementName = "TeamRedirectOpen")]
        public List<TeamRedirectOpen> TeamRedirectOpen { get; set; }

        [XmlElement(ElementName = "TeamRedirectClose")]
        public List<TeamRedirectClose> TeamRedirectClose { get; set; }

        [XmlElement(ElementName = "TeamRedirectClosed")]
        public List<TeamRedirectClosed> TeamRedirectClosed { get; set; }

        [XmlElement(ElementName = "TeamRedirectRouting")]
        public List<TeamRedirectRouting> TeamRedirectRouting { get; set; }

        [XmlElement(ElementName = "TeamRedirectMessage")]
        public List<TeamRedirectMessage> TeamRedirectMessage { get; set; }

        [XmlElement(ElementName = "TeamRedirectNumber")]
        public List<TeamRedirectNumber> TeamRedirectNumber { get; set; }

        [XmlElement(ElementName = "BankHoliday")]
        public List<BankHoliday> BankHoliday { get; set; }

        [XmlElement(ElementName = "BankHolidayOpen")]
        public List<BankHoliday> BankHolidayOpen { get; set; }

        [XmlElement(ElementName = "BankHolidayClose")]
        public List<BankHoliday> BankHolidayClose { get; set; }

        [XmlElement(ElementName = "BankHolidayClosed")]
        public List<BankHoliday> BankHolidayClosed { get; set; }
    }
}
