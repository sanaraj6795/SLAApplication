﻿using System.Xml.Serialization;

namespace SLADashboard.Api.DTO
{
    [XmlRoot(ElementName = "Emergency")]
    public class Emergency
    {
        [XmlElement(ElementName = "location1")]
        public XmlIdText Location1 { get; set; }

        [XmlElement(ElementName = "location2")]
        public XmlIdText Location2 { get; set; }
    }
}
