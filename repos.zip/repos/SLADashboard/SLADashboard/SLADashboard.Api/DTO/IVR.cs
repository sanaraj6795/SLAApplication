﻿using System.Xml.Serialization;

namespace SLADashboard.Api.DTO
{
    [XmlRoot(ElementName = "IVR")]
    public class IVR
    {
        [XmlElement(ElementName = "IVR_Option")]
        public string IVR_Option { get; set; }
        [XmlElement(ElementName = "menuOptions")]
        public string MenuOptions { get; set; }
        [XmlElement(ElementName = "menuLoopCounterLimit")]
        public string MenuLoopCounterLimit { get; set; }
        [XmlElement(ElementName = "option1Route")]
        public string Option1Route { get; set; }
        [XmlElement(ElementName = "option1CSQ")]
        public string Option1CSQ { get; set; }
        [XmlElement(ElementName = "option2Route")]
        public string Option2Route { get; set; }
        [XmlElement(ElementName = "option2CSQ")]
        public string Option2CSQ { get; set; }
        [XmlElement(ElementName = "option3Route")]
        public string Option3Route { get; set; }
        [XmlElement(ElementName = "option3CSQ")]
        public string Option3CSQ { get; set; }
        [XmlElement(ElementName = "option4Route")]
        public string Option4Route { get; set; }
        [XmlElement(ElementName = "option4CSQ")]
        public string Option4CSQ { get; set; }
        [XmlElement(ElementName = "option5Route")]
        public string Option5Route { get; set; }
        [XmlElement(ElementName = "option5CSQ")]
        public string Option5CSQ { get; set; }
        [XmlElement(ElementName = "option6Route")]
        public string Option6Route { get; set; }
        [XmlElement(ElementName = "option6CSQ")]
        public string Option6CSQ { get; set; }
        [XmlElement(ElementName = "overflowRoute")]
        public string OverflowRoute { get; set; }
        [XmlElement(ElementName = "overflowCSQ")]
        public string OverflowCSQ { get; set; }
        [XmlElement(ElementName = "DNISOptions")]
        public string DNISOptions { get; set; }
        [XmlElement(ElementName = "DNIS1Route")]
        public string DNIS1Route { get; set; }
        [XmlElement(ElementName = "DNIS2Route")]
        public string DNIS2Route { get; set; }
        [XmlElement(ElementName = "DNIS3Route")]
        public string DNIS3Route { get; set; }
        [XmlElement(ElementName = "DNIS4Route")]
        public string DNIS4Route { get; set; }
        [XmlElement(ElementName = "DNIS5Route")]
        public string DNIS5Route { get; set; }
        [XmlElement(ElementName = "DNIS6Route")]
        public string DNIS6Route { get; set; }
        [XmlElement(ElementName = "DNIS7Route")]
        public string DNIS7Route { get; set; }
        [XmlElement(ElementName = "DNIS8Route")]
        public string DNIS8Route { get; set; }
        [XmlElement(ElementName = "DNIS9Route")]
        public string DNIS9Route { get; set; }
        [XmlElement(ElementName = "DNIS10Route")]
        public string DNIS10Route { get; set; }
        [XmlElement(ElementName = "DNIS1")]
        public string DNIS1 { get; set; }
        [XmlElement(ElementName = "DNIS2")]
        public string DNIS2 { get; set; }
        [XmlElement(ElementName = "DNIS3")]
        public string DNIS3 { get; set; }
        [XmlElement(ElementName = "DNIS4")]
        public string DNIS4 { get; set; }
        [XmlElement(ElementName = "DNIS5")]
        public string DNIS5 { get; set; }
        [XmlElement(ElementName = "DNIS6")]
        public string DNIS6 { get; set; }
        [XmlElement(ElementName = "DNIS7")]
        public string DNIS7 { get; set; }
        [XmlElement(ElementName = "DNIS8")]
        public string DNIS8 { get; set; }
        [XmlElement(ElementName = "DNIS9")]
        public string DNIS9 { get; set; }
        [XmlElement(ElementName = "DNIS10")]
        public string DNIS10 { get; set; }
        [XmlElement(ElementName = "DNIS1_CSQ")]
        public string DNIS1_CSQ { get; set; }
        [XmlElement(ElementName = "DNIS2_CSQ")]
        public string DNIS2_CSQ { get; set; }
        [XmlElement(ElementName = "DNIS3_CSQ")]
        public string DNIS3_CSQ { get; set; }
        [XmlElement(ElementName = "DNIS4_CSQ")]
        public string DNIS4_CSQ { get; set; }
        [XmlElement(ElementName = "DNIS5_CSQ")]
        public string DNIS5_CSQ { get; set; }
        [XmlElement(ElementName = "DNIS6_CSQ")]
        public string DNIS6_CSQ { get; set; }
        [XmlElement(ElementName = "DNIS7_CSQ")]
        public string DNIS7_CSQ { get; set; }
        [XmlElement(ElementName = "DNIS8_CSQ")]
        public string DNIS8_CSQ { get; set; }
        [XmlElement(ElementName = "DNIS9_CSQ")]
        public string DNIS9_CSQ { get; set; }
        [XmlElement(ElementName = "DNIS10_CSQ")]
        public string DNIS10_CSQ { get; set; }
        [XmlElement(ElementName = "option7Route")]
        public string Option7Route { get; set; }
        [XmlElement(ElementName = "option7CSQ")]
        public string Option7CSQ { get; set; }
        [XmlElement(ElementName = "option8Route")]
        public string Option8Route { get; set; }
        [XmlElement(ElementName = "option8CSQ")]
        public string Option8CSQ { get; set; }
        [XmlElement(ElementName = "option9Route")]
        public string Option9Route { get; set; }
        [XmlElement(ElementName = "option9CSQ")]
        public string Option9CSQ { get; set; }
        [XmlElement(ElementName = "option0Route")]
        public string Option0Route { get; set; }
        [XmlElement(ElementName = "option0CSQ")]
        public string Option0CSQ { get; set; }
        [XmlElement(ElementName = "optionStarRoute")]
        public string OptionStarRoute { get; set; }
        [XmlElement(ElementName = "optionStarCSQ")]
        public string OptionStarCSQ { get; set; }
        [XmlElement(ElementName = "optionHashRoute")]
        public string OptionHashRoute { get; set; }
        [XmlElement(ElementName = "optionHashCSQ")]
        public string OptionHashCSQ { get; set; }
        [XmlElement(ElementName = "option1Required")]
        public string Option1Required { get; set; }
        [XmlElement(ElementName = "option2Required")]
        public string Option2Required { get; set; }
        [XmlElement(ElementName = "option3Required")]
        public string Option3Required { get; set; }
        [XmlElement(ElementName = "option4Required")]
        public string Option4Required { get; set; }
        [XmlElement(ElementName = "option5Required")]
        public string Option5Required { get; set; }
        [XmlElement(ElementName = "option6Required")]
        public string Option6Required { get; set; }
        [XmlElement(ElementName = "option7Required")]
        public string Option7Required { get; set; }
        [XmlElement(ElementName = "option8Required")]
        public string Option8Required { get; set; }
        [XmlElement(ElementName = "option9Required")]
        public string Option9Required { get; set; }
        [XmlElement(ElementName = "option0Required")]
        public string Option0Required { get; set; }
        [XmlElement(ElementName = "optionStarRequired")]
        public string OptionStarRequired { get; set; }
        [XmlElement(ElementName = "optionHashRequired")]
        public string OptionHashRequired { get; set; }
        [XmlElement(ElementName = "menuReturn")]
        public string MenuReturn { get; set; }
        [XmlAttribute(AttributeName = "id")]
        public string Id { get; set; }
    }
}
