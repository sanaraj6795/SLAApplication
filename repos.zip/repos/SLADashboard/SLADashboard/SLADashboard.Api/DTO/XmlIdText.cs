﻿using System.Xml.Serialization;

namespace SLADashboard.Api.DTO
{
    public class XmlIdText
    {
        [XmlAttribute(AttributeName = "id")]
        public string Id { get; set; }

        [XmlText]
        public string Text { get; set; }
    }
}
