﻿using System.Collections.Generic;
using System.Xml.Serialization;

namespace SLADashboard.Api.DTO
{
    [XmlRoot(ElementName = "BankHoliday")]
    public class BankHoliday
    {
        [XmlElement(ElementName = "bankHolidayDate")]
        public List<XmlIdText> BankHolidayDate { get; set; }

        [XmlAttribute(AttributeName = "id")]
        public string Id { get; set; }
    }
}
