﻿using System.Xml.Serialization;

namespace SLADashboard.Api.DTO
{
    [XmlRoot(ElementName = "Motd")]
    public class Motd
    {
        [XmlElement(ElementName = "enablePlayMotd")]
        public string EnablePlayMotd { get; set; }

        [XmlElement(ElementName = "motdMessage")]
        public string MotdMessage { get; set; }

        [XmlElement(ElementName = "motdCounter")]
        public string MotdCounter { get; set; }

        [XmlAttribute(AttributeName = "id")]
        public string Id { get; set; }
    }
}
