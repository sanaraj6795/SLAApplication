﻿using System.Collections.Generic;
using System.Xml.Serialization;

namespace SLADashboard.Api.DTO
{
    [XmlRoot(ElementName = "TeamRedirectMessage")]
    public class TeamRedirectMessage
    {
        [XmlElement(ElementName = "teamRedirectMessage")]
        public List<XmlIdText> TeamRedirectMessageInner { get; set; }

        [XmlAttribute(AttributeName = "id")]
        public string Id { get; set; }
    }
}
