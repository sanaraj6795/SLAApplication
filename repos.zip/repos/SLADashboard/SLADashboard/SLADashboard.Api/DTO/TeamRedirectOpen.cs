﻿using System.Collections.Generic;
using System.Xml.Serialization;

namespace SLADashboard.Api.DTO
{
    [XmlRoot(ElementName = "TeamRedirectOpen")]
    public class TeamRedirectOpen
    {
        [XmlElement(ElementName = "teamRedirectOpen")]
        public List<XmlIdText> TeamRedirectOpenInner { get; set; }

        [XmlAttribute(AttributeName = "id")]
        public string Id { get; set; }
    }
}
