﻿using System.Xml.Serialization;

namespace SLADashboard.Api.DTO
{
    [XmlRoot(ElementName = "BankHolidayEnabled")]
    public class BankHolidayEnabled
    {
        [XmlElement(ElementName = "checkHolidayDays")]
        public string CheckHolidayDays { get; set; }

        [XmlElement(ElementName = "holidayCounter")]
        public string HolidayCounter { get; set; }

        [XmlElement(ElementName = "individualMessages")]
        public string IndividualMessages { get; set; }

        [XmlAttribute(AttributeName = "id")]
        public string Id { get; set; }
    }
}
