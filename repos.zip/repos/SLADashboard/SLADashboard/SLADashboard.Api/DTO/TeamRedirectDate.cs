﻿using System.Collections.Generic;
using System.Xml.Serialization;

namespace SLADashboard.Api.DTO
{
    [XmlRoot(ElementName = "TeamRedirectDate")]
    public class TeamRedirectDate
    {
        [XmlElement(ElementName = "teamRedirectDate")]
        public List<XmlIdText> TeamRedirectDateInner { get; set; }

        [XmlAttribute(AttributeName = "id")]
        public string Id { get; set; }
    }
}
