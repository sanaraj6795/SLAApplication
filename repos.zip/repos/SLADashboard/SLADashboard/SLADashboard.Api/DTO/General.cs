﻿using System.Xml.Serialization;

namespace SLADashboard.Api.DTO
{
    [XmlRoot(ElementName = "General")]
    public class General
    {
        [XmlElement(ElementName = "agentTimeout")]
        public string AgentTimeout { get; set; }

        [XmlElement(ElementName = "locCounter")]
        public string LocCounter { get; set; }
    }
}
