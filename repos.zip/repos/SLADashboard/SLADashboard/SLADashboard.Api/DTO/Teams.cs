﻿using System.Collections.Generic;
using System.Xml.Serialization;

namespace SLADashboard.Api.DTO
{
    [XmlRoot(ElementName = "Teams")]
    public class Teams
    {
        [XmlElement(ElementName = "team")]
        public List<XmlIdText> Team { get; set; }
    }
}
