﻿using System.Collections.Generic;
using System.Xml.Serialization;

namespace SLADashboard.Api.DTO
{
    [XmlRoot(ElementName = "RoutePoints")]
    public class RoutePoints
    {
        [XmlElement(ElementName = "routePoint")]
        public List<XmlIdText> RoutePoint { get; set; }
    }
}
