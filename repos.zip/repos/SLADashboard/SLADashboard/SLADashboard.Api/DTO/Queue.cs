﻿using System.Xml.Serialization;

namespace SLADashboard.Api.DTO
{
    [XmlRoot(ElementName = "Queue")]
    public class Queue
    {
        [XmlElement(ElementName = "inQueueMessageDelay")]
        public string InQueueMessageDelay { get; set; }
        [XmlElement(ElementName = "enablePositionInQueue")]
        public string EnablePositionInQueue { get; set; }
        [XmlElement(ElementName = "voicemailOptionEnabled")]
        public string VoicemailOptionEnabled { get; set; }
        [XmlElement(ElementName = "voicemailOptionTimeout")]
        public string VoicemailOptionTimeout { get; set; }
        [XmlElement(ElementName = "voicemailOptionDN")]
        public string VoicemailOptionDN { get; set; }
        [XmlElement(ElementName = "messageOrder")]
        public string MessageOrder { get; set; }
        [XmlElement(ElementName = "messageNumber")]
        public string MessageNumber { get; set; }
        [XmlElement(ElementName = "enableDivertTime")]
        public string EnableDivertTime { get; set; }
        [XmlElement(ElementName = "enableDivertTimeTimer")]
        public string EnableDivertTimeTimer { get; set; }
        [XmlElement(ElementName = "enableDivertTimeNumber")]
        public string EnableDivertTimeNumber { get; set; }
        [XmlElement(ElementName = "enableDivertCallers")]
        public string EnableDivertCallers { get; set; }
        [XmlElement(ElementName = "enableDivertCallersLevel")]
        public string EnableDivertCallersLevel { get; set; }
        [XmlElement(ElementName = "enableDivertCallersNumber")]
        public string EnableDivertCallersNumber { get; set; }
        [XmlElement(ElementName = "noAgentsPrompt")]
        public string NoAgentsPrompt { get; set; }
        [XmlElement(ElementName = "noAgentsDivert")]
        public string NoAgentsDivert { get; set; }
        [XmlElement(ElementName = "noAgentsDN")]
        public string NoAgentsDN { get; set; }
        [XmlAttribute(AttributeName = "id")]
        public string Id { get; set; }
    }
}
