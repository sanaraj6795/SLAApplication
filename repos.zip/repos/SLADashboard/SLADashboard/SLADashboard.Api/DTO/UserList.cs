﻿using System.Collections.Generic;
using System.Xml.Serialization;

namespace SLADashboard.Api.DTO
{
    [XmlRoot(ElementName = "UserList")]
    public class UserList
    {
        [XmlElement(ElementName = "user")]
        public List<XmlIdText> User { get; set; }
    }
}
