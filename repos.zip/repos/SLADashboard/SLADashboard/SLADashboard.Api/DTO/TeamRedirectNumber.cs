﻿using System.Collections.Generic;
using System.Xml.Serialization;

namespace SLADashboard.Api.DTO
{
    [XmlRoot(ElementName = "TeamRedirectNumber")]
    public class TeamRedirectNumber
    {
        [XmlElement(ElementName = "teamRedirectNumber")]
        public List<XmlIdText> TeamRedirectNumberInner { get; set; }

        [XmlAttribute(AttributeName = "id")]
        public string Id { get; set; }
    }
}
