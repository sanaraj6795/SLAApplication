﻿using System.Xml.Serialization;

namespace SLADashboard.Api.DTO
{
    [XmlRoot(ElementName = "TeamRedirect")]
    public class TeamRedirect
    {
        [XmlElement(ElementName = "checkTeamRedirect")]
        public string CheckTeamRedirect { get; set; }

        [XmlElement(ElementName = "individualMessages")]
        public string IndividualMessages { get; set; }

        [XmlElement(ElementName = "redirectCounter")]
        public string RedirectCounter { get; set; }

        [XmlAttribute(AttributeName = "id")]
        public string Id { get; set; }
    }
}
