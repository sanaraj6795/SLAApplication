﻿using System.Xml.Serialization;

namespace SLADashboard.Api.DTO
{
    [XmlRoot(ElementName = "Locations")]
    public class Locations
    {
        [XmlElement(ElementName = "location1")]
        public XmlIdText Location1 { get; set; }
        [XmlElement(ElementName = "location2")]
        public XmlIdText Location2 { get; set; }
    }
}
