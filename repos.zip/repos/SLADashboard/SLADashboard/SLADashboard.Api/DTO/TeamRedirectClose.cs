﻿using System.Collections.Generic;
using System.Xml.Serialization;

namespace SLADashboard.Api.DTO
{
    [XmlRoot(ElementName = "TeamRedirectClose")]
    public class TeamRedirectClose
    {
        [XmlElement(ElementName = "teamRedirectClose")]
        public List<XmlIdText> TeamRedirectCloseInner { get; set; }

        [XmlAttribute(AttributeName = "id")]
        public string Id { get; set; }
    }
}
