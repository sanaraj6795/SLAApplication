﻿using System.Xml.Serialization;

namespace SLADashboard.Api.DTO
{
    [XmlRoot(ElementName = "OutOfHours")]
    public class OutOfHours
    {
        [XmlElement(ElementName = "enableMessageOOH")]
        public string EnableMessageOOH { get; set; }

        [XmlElement(ElementName = "enableVoicemailRedirectOOH")]
        public string EnableVoicemailRedirectOOH { get; set; }

        [XmlElement(ElementName = "dnOOH")]
        public string DnOOH { get; set; }

        [XmlElement(ElementName = "enableMessageBankHoliday")]
        public string EnableMessageBankHoliday { get; set; }

        [XmlElement(ElementName = "enableVoicemailRedirectBankHoliday")]
        public string EnableVoicemailRedirectBankHoliday { get; set; }

        [XmlElement(ElementName = "dnBankHoliday")]
        public string DnBankHoliday { get; set; }

        [XmlAttribute(AttributeName = "id")]
        public string Id { get; set; }
    }
}
