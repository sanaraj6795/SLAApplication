﻿using System.Xml.Serialization;

namespace SLADashboard.Api.DTO
{
    [XmlRoot(ElementName = "UserSettings")]
    public class UserSettings
    {
        [XmlElement(ElementName = "password")]
        public string Password { get; set; }

        [XmlElement(ElementName = "accountType")]
        public string AccountType { get; set; }

        [XmlElement(ElementName = "callFlow01")]
        public string CallFlow01 { get; set; }

        [XmlAttribute(AttributeName = "id")]
        public string Id { get; set; }

        [XmlElement(ElementName = "callFlow02")]
        public string CallFlow02 { get; set; }

        [XmlElement(ElementName = "callFlow03")]
        public string CallFlow03 { get; set; }

        [XmlElement(ElementName = "callFlow04")]
        public string CallFlow04 { get; set; }

        [XmlElement(ElementName = "callFlow05")]
        public string CallFlow05 { get; set; }

        [XmlElement(ElementName = "callFlow06")]
        public string CallFlow06 { get; set; }
        [XmlElement(ElementName = "callFlow07")]
        public string CallFlow07 { get; set; }

        [XmlElement(ElementName = "callFlow08")]
        public string CallFlow08 { get; set; }

        [XmlElement(ElementName = "callFlow09")]
        public string CallFlow09 { get; set; }

        [XmlElement(ElementName = "callFlow10")]
        public string CallFlow10 { get; set; }

        [XmlElement(ElementName = "callFlow11")]
        public string CallFlow11 { get; set; }

        [XmlElement(ElementName = "callFlow12")]
        public string CallFlow12 { get; set; }

        [XmlElement(ElementName = "callFlow13")]
        public string CallFlow13 { get; set; }
    }
}
