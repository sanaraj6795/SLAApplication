﻿using System.Xml.Serialization;

namespace SLADashboard.Api.DTO
{
    [XmlRoot(ElementName = "WelcomeMessage")]
    public class WelcomeMessage
    {
        [XmlElement(ElementName = "enableWelcomeMessage")]
        public string EnableWelcomeMessage { get; set; }

        [XmlAttribute(AttributeName = "id")]
        public string Id { get; set; }
    }
}
