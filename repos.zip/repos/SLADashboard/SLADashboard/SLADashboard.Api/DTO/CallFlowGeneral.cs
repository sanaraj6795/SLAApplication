﻿using System.Xml.Serialization;

namespace SLADashboard.Api.DTO
{
    [XmlRoot(ElementName = "CallFlowGeneral")]
    public class CallFlowGeneral
    {
        [XmlElement(ElementName = "location")]
        public string Location { get; set; }

        [XmlElement(ElementName = "genericMessages")]
        public string GenericMessages { get; set; }

        [XmlAttribute(AttributeName = "id")]
        public string Id { get; set; }
    }
}
