﻿using System.Collections.Generic;
using System.Xml.Serialization;

namespace SLADashboard.Api.DTO
{
    [XmlRoot(ElementName = "TeamRedirectRouting")]
    public class TeamRedirectRouting
    {
        [XmlElement(ElementName = "teamRedirectRouting")]
        public List<XmlIdText> TeamRedirectRoutingInner { get; set; }

        [XmlAttribute(AttributeName = "id")]
        public string Id { get; set; }
    }
}
