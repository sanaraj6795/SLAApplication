﻿using System.Collections.Generic;
using AutoMapper;
using SLADashboard.Api.DTO;
using SLADashboard.Api.Model;

namespace SLADashboard.Api.Mappers
{
    public class DashboardProfile : Profile
    {
        public DashboardProfile()
        {
            CreateMap<XmlIdText, UserManagementModel>(MemberList.None)
                .ForMember(x => x.Type, o => o.MapFrom(s => s.Text));

            CreateMap<XmlIdText, TeamsModel>(MemberList.None)
                .ForMember(x => x.Type, o => o.MapFrom(s => s.Text));

            CreateMap<UserSettings, UserSettingsModel>(MemberList.None)
                .ForMember(x => x.CallFlows, o => o.MapFrom(s => MapUserSettings(s)));

            CreateMap<XmlIdText, BankHolidayDate>(MemberList.None);

            CreateMap<BankHolidayEnabled, BankHolidayEnabledModel>(MemberList.None);

            CreateMap<OpeningTimes, OpeningTimesModel>(MemberList.None);
        }

        private List<CallFlowData> MapUserSettings(UserSettings userSettings)
        {
            return new List<CallFlowData>
            {
                new CallFlowData("01", userSettings.CallFlow01),
                new CallFlowData("02", userSettings.CallFlow02),
                new CallFlowData("03", userSettings.CallFlow03),
                new CallFlowData("04", userSettings.CallFlow04),
                new CallFlowData("05", userSettings.CallFlow05),
                new CallFlowData("06", userSettings.CallFlow06),
                new CallFlowData("07", userSettings.CallFlow07),
                new CallFlowData("08", userSettings.CallFlow08),
                new CallFlowData("09", userSettings.CallFlow09),
                new CallFlowData("10", userSettings.CallFlow10),
                new CallFlowData("11", userSettings.CallFlow11),
                new CallFlowData("12", userSettings.CallFlow12),
                new CallFlowData("13", userSettings.CallFlow13),
            };
        }
    }
}
