﻿using AutoMapper;
using SLADashboard.Api.DTO;
using SLADashboard.Api.Model;

namespace SLADashboard.Api.Mappers
{
    public class MapperConfig
    {
        public static IMapper Mapper { get; set; }

        public static IMapper CreateMapper()
        {
            if (Mapper == null)
            {
                Mapper = Configure().CreateMapper();
            }

            return Mapper;
        }

        public static MapperConfiguration Configure()
        {
            var configuration = new MapperConfiguration(config =>
            {
                //config.CreateMap<XmlIdText, UserManagementModel>(MemberList.None)
                //.ForMember(x => x.Type, o => o.MapFrom(s => s.Text));
            });

            configuration.AssertConfigurationIsValid();

            return configuration;
        }
    }
}
