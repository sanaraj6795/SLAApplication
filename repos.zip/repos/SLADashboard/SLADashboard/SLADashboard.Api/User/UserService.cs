﻿using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using NetCore.AutoRegisterDi;

namespace SLADashboard.Api.User
{
    [RegisterAsScoped]
    public class UserService : IUserService
    {
        public AppUser CurrentUser { get; private set; }

        public UserService()
        {
        }

        public void CreateUser(ClaimsPrincipal currentUser)
        {
            var userName = currentUser.Claims.First(c => c.Type == ClaimConstants.UserName).Value;
            var userId = currentUser.Claims.First(c => c.Type == JwtRegisteredClaimNames.Sid).Value;

            this.CurrentUser = new AppUser(userName, userId);
        }
    }
}
