﻿using System.Security.Claims;

namespace SLADashboard.Api.User
{
    public interface IUserService
    {
        AppUser CurrentUser { get; }

        void CreateUser(ClaimsPrincipal currentUser);
    }
}
