﻿namespace SLADashboard.Api.User
{
    public class AppUser
    {
        public AppUser(string userName, string userId)
        {
            UserName = userName;
            UserId = userId;
        }

        public string UserName { get; private set; }

        public string UserId { get; private set; }
    }
}
