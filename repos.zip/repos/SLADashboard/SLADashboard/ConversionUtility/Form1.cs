﻿using System;
using System.Windows.Forms;

namespace ConversionUtility
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnConvert_Click(object sender, EventArgs e)
        {
            txtEncoded.Text = txtUser.Text.Base64Encode();

            if(MessageBox.Show("Do you want to copy the text?", "Copy text", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                Clipboard.SetText(txtEncoded.Text);
                MessageBox.Show("Text copied. Please paste wherever necessary");
            }            
        }

        private void btnDecode_Click(object sender, EventArgs e)
        {
            txtDecoded.Text = txtEncodedInput.Text.ConvertFromBase64String();

            if (MessageBox.Show("Do you want to copy the text?", "Copy text", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                Clipboard.SetText(txtDecoded.Text);
                MessageBox.Show("Text copied. Please paste wherever necessary");
            }
        }
    }
}
