﻿namespace ConversionUtility
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtUser = new System.Windows.Forms.TextBox();
            this.btnConvert = new System.Windows.Forms.Button();
            this.txtEncoded = new System.Windows.Forms.TextBox();
            this.txtDecoded = new System.Windows.Forms.TextBox();
            this.btnDecode = new System.Windows.Forms.Button();
            this.txtEncodedInput = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // txtUser
            // 
            this.txtUser.Location = new System.Drawing.Point(12, 12);
            this.txtUser.Name = "txtUser";
            this.txtUser.Size = new System.Drawing.Size(258, 20);
            this.txtUser.TabIndex = 0;
            // 
            // btnConvert
            // 
            this.btnConvert.Location = new System.Drawing.Point(305, 12);
            this.btnConvert.Name = "btnConvert";
            this.btnConvert.Size = new System.Drawing.Size(120, 23);
            this.btnConvert.TabIndex = 1;
            this.btnConvert.Text = "Encode";
            this.btnConvert.UseVisualStyleBackColor = true;
            this.btnConvert.Click += new System.EventHandler(this.btnConvert_Click);
            // 
            // txtEncoded
            // 
            this.txtEncoded.Location = new System.Drawing.Point(459, 12);
            this.txtEncoded.Name = "txtEncoded";
            this.txtEncoded.ReadOnly = true;
            this.txtEncoded.Size = new System.Drawing.Size(258, 20);
            this.txtEncoded.TabIndex = 2;
            // 
            // txtDecoded
            // 
            this.txtDecoded.Location = new System.Drawing.Point(459, 62);
            this.txtDecoded.Name = "txtDecoded";
            this.txtDecoded.ReadOnly = true;
            this.txtDecoded.Size = new System.Drawing.Size(258, 20);
            this.txtDecoded.TabIndex = 5;
            // 
            // btnDecode
            // 
            this.btnDecode.Location = new System.Drawing.Point(305, 62);
            this.btnDecode.Name = "btnDecode";
            this.btnDecode.Size = new System.Drawing.Size(120, 23);
            this.btnDecode.TabIndex = 4;
            this.btnDecode.Text = "Decode";
            this.btnDecode.UseVisualStyleBackColor = true;
            this.btnDecode.Click += new System.EventHandler(this.btnDecode_Click);
            // 
            // txtEncodedInput
            // 
            this.txtEncodedInput.Location = new System.Drawing.Point(12, 62);
            this.txtEncodedInput.Name = "txtEncodedInput";
            this.txtEncodedInput.Size = new System.Drawing.Size(258, 20);
            this.txtEncodedInput.TabIndex = 3;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtDecoded);
            this.Controls.Add(this.btnDecode);
            this.Controls.Add(this.txtEncodedInput);
            this.Controls.Add(this.txtEncoded);
            this.Controls.Add(this.btnConvert);
            this.Controls.Add(this.txtUser);
            this.Name = "Form1";
            this.Text = "Utility";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtUser;
        private System.Windows.Forms.Button btnConvert;
        private System.Windows.Forms.TextBox txtEncoded;
        private System.Windows.Forms.TextBox txtDecoded;
        private System.Windows.Forms.Button btnDecode;
        private System.Windows.Forms.TextBox txtEncodedInput;
    }
}

